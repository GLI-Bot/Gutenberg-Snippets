# Gutenberg Snippets

<!-- Plugin description -->
Simple snippets for custom gutenberg blocks based on React 16

<!-- Plugin description end -->
## Installation

---
- Using IDE built-in plugin system:
  
  <kbd>Settings/Preferences</kbd> > <kbd>Plugins</kbd> > <kbd>Marketplace</kbd> > <kbd>Search for "Gutenberg Snippets"</kbd> >
  <kbd>Install Plugin</kbd>

## Snippets

- `gbie` Edit with Inspector Controls
- `gbe`  Edit
- `gbs`  Save
- `gbi`  Index
- `gbj`  Json

---

## Inspiration 
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
