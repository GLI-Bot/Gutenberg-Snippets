rootProject.name = "gli-gutenberg-snippets-jetbrains"
